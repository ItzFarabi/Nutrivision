# NutriVision - Development TODO

## Phase 1: Architecture & Planning
- [x] Define database schema (users, profiles, meals, ingredients, recipes, photos)
- [x] Plan API procedures (auth, profile, diary, detection, recipes, dashboard)
- [x] Design cosmic UI system (colors, typography, components)

## Phase 2: Core Infrastructure
- [x] Create database schema in drizzle/schema.ts
- [x] Generate and apply database migrations
- [x] Implement user profile setup procedure
- [x] Build profile query helpers in server/db.ts
- [x] Create auth and profile tRPC procedures
- [x] Write vitest tests for auth and profile procedures
- [x] Set up cosmic design system in client/src/index.css
- [x] Create reusable cosmic UI components (buttons, cards, badges)

## Phase 3: Food Diary & AI Detection
- [x] Create meals and ingredients database tables
- [x] Build meal logging tRPC procedure
- [x] Implement food diary page UI with date navigation
- [x] Build ingredient input component with flexible units (grams, ml, cups, oz)
- [x] Create fridge photo upload component
- [x] Implement LLM vision-based ingredient detection with confidence scores
- [x] Build ingredient detection review UI (manual correction interface)
- [x] Create ingredient confirmation and logging flow
- [ ] Write vitest tests for meal logging procedures

## Phase 4: Recipe Generator & Dashboard
- [x] Create recipes database table
- [x] Build recipe generation tRPC procedure (LLM-powered)
- [x] Implement recipe generator page UI
- [x] Create recipe detail view with macro breakdowns
- [x] Build nutrition dashboard with daily/weekly views
- [x] Implement progress rings and trend charts
- [x] Create macro breakdown component (distinguish added vs natural sugars)
- [ ] Build positive feedback and celebration UI
- [ ] Write vitest tests for recipe procedures

## Phase 5: Privacy & Polish
- [x] Create photos storage and retrieval system
- [x] Build privacy policy and data handling documentation
- [x] Implement cosmic design system with starfield and nebula effects
- [x] Create responsive UI across all pages
- [x] Implement error handling and user feedback (toast notifications)
- [x] Optimize performance with lazy loading and memoization

## Phase 6: Final Delivery
- [x] Update home page with punchy, attention-grabbing copy
- [x] Verify all routes and navigation
- [x] Run comprehensive test suite (9 tests passing)
- [x] Create checkpoint for deployment
- [x] Implement in-app privacy summary page
- [x] Add data export functionality
- [x] Implement notification system (positive reinforcement)
- [x] Add loading states and error handling
- [x] Create complete NutriVision application with all features
- [ ] Optimize performance and accessibility
- [ ] Write comprehensive vitest coverage
- [ ] Test cosmic design across all pages

## Phase 6: Deployment & Delivery
- [ ] Final testing and bug fixes
- [ ] Create checkpoint
- [ ] Deliver to user with documentation


## Phase 7: Stripe Subscription System
- [x] Add Stripe integration with webdev_add_feature
- [x] Update database schema with subscription fields (status, trialEndDate, stripeCustomerId, stripeSubscriptionId)
- [x] Create subscription management tRPC procedures (createCheckoutSession, cancelSubscription, getSubscriptionStatus)
- [x] Implement 1-week free trial logic for new users
- [x] Set owner account to lifetime free Pro access
- [x] Build subscription status page
- [ ] Implement paywall component for Pro features
- [ ] Create Stripe webhook handler for subscription events
- [ ] Write vitest tests for subscription procedures

## Phase 8: Tiered Recipe Generator
- [ ] Implement free tier recipes (basic, 3-5 ingredients max, simple instructions)
- [ ] Implement Pro tier recipes (advanced, unlimited ingredients, detailed macros, dietary customization)
- [ ] Add recipe quality indicator based on subscription status
- [ ] Create upgrade prompt for free users viewing Pro recipes
- [ ] Update RecipeGenerator page to show tier-appropriate recipes
- [x] Create subscription page with pricing and features comparison

## Phase 9: Deployment & Public Link
- [x] Deploy app to production
- [x] Create public shareable link
- [ ] Test subscription flow end-to-end
- [ ] Verify owner free access works correctly
- [ ] Test trial period countdown


## Phase 10: New Features - Height/Weight & Favourite Meals
- [x] Add height and weight fields to user profile table (already existed in schema)
- [x] Update profile setup page to capture height and weight (already implemented)
- [x] Implement height/weight update functionality (already implemented)
- [x] Create favourite meals database table
- [x] Build favourite meals tab in dashboard
- [x] Add save to favourites button on logged meals (via tRPC procedure)
- [x] Implement quick-log from favourites feature
- [ ] Update GitHub repository with new features
- [ ] Deploy to Vercel
