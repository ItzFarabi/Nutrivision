import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Lock, Download, Trash2, Eye } from "lucide-react";

export default function Privacy() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-background text-foreground py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4">
            <Lock className="w-10 h-10 text-accent glow-text-cyan" />
            <h1 className="text-4xl font-bold glow-text">Your Data, Your Control</h1>
          </div>
          <p className="text-lg text-muted-foreground">
            We believe your health data is sacred. Here's exactly how we handle it.
          </p>
        </div>

        {/* Core Principles */}
        <div className="space-y-6 mb-12">
          <Card className="card-cosmic p-8">
            <h2 className="text-2xl font-bold mb-4 text-accent">Our Commitment</h2>
            <ul className="space-y-4">
              <li className="flex gap-4">
                <span className="text-accent font-bold">✓</span>
                <div>
                  <p className="font-semibold mb-1">No Third-Party Sharing</p>
                  <p className="text-muted-foreground">
                    Your nutrition data is never sold, shared, or given to advertisers. Period.
                  </p>
                </div>
              </li>
              <li className="flex gap-4">
                <span className="text-accent font-bold">✓</span>
                <div>
                  <p className="font-semibold mb-1">Encrypted Storage</p>
                  <p className="text-muted-foreground">
                    All data is encrypted at rest and in transit using industry-standard protocols.
                  </p>
                </div>
              </li>
              <li className="flex gap-4">
                <span className="text-accent font-bold">✓</span>
                <div>
                  <p className="font-semibold mb-1">Full Transparency</p>
                  <p className="text-muted-foreground">
                    You can see exactly what data we store and request deletion anytime.
                  </p>
                </div>
              </li>
              <li className="flex gap-4">
                <span className="text-accent font-bold">✓</span>
                <div>
                  <p className="font-semibold mb-1">No AI Training Data</p>
                  <p className="text-muted-foreground">
                    Your meals, photos, and nutrition data are never used to train AI models.
                  </p>
                </div>
              </li>
            </ul>
          </Card>
        </div>

        {/* What We Collect */}
        <div className="space-y-6 mb-12">
          <Card className="card-cosmic p-8">
            <h2 className="text-2xl font-bold mb-6 text-accent">What We Collect</h2>
            
            <div className="space-y-6">
              <div>
                <h3 className="font-bold text-lg mb-2">Profile Information</h3>
                <p className="text-muted-foreground mb-3">
                  Age, height, weight, activity level, and dietary goals—used only to calculate your personalized nutrition targets.
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-2">Meal & Nutrition Data</h3>
                <p className="text-muted-foreground mb-3">
                  Every ingredient you log, with quantities and macros. This data stays private and is never shared.
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-2">Fridge Photos</h3>
                <p className="text-muted-foreground mb-3">
                  Photos you upload are processed for ingredient detection, then securely stored so you can review past scans.
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-2">Usage Analytics (Optional)</h3>
                <p className="text-muted-foreground mb-3">
                  Anonymous usage patterns help us improve the app. You can opt out anytime in settings.
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* Data Rights */}
        <div className="space-y-6 mb-12">
          <Card className="card-cosmic p-8">
            <h2 className="text-2xl font-bold mb-6 text-accent">Your Data Rights</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="p-6 rounded-lg bg-accent/5 border border-accent/20">
                <div className="flex items-start gap-3 mb-4">
                  <Download className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <h3 className="font-bold text-lg">Export Your Data</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Download all your meals, nutrition data, and photos in a portable format.
                </p>
                <Button variant="outline" className="border-border/50 w-full">
                  Export Data
                </Button>
              </div>

              <div className="p-6 rounded-lg bg-accent/5 border border-accent/20">
                <div className="flex items-start gap-3 mb-4">
                  <Eye className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <h3 className="font-bold text-lg">View Your Data</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  See exactly what we store about you in a clear, readable format.
                </p>
                <Button variant="outline" className="border-border/50 w-full">
                  View Data
                </Button>
              </div>

              <div className="p-6 rounded-lg bg-accent/5 border border-accent/20">
                <div className="flex items-start gap-3 mb-4">
                  <Trash2 className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <h3 className="font-bold text-lg">Delete Your Data</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Permanently delete all your data. This action cannot be undone.
                </p>
                <Button variant="outline" className="border-border/50 w-full text-red-400 hover:bg-red-500/10">
                  Delete Everything
                </Button>
              </div>

              <div className="p-6 rounded-lg bg-accent/5 border border-accent/20">
                <div className="flex items-start gap-3 mb-4">
                  <Lock className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <h3 className="font-bold text-lg">Privacy Settings</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Control analytics, notifications, and data retention preferences.
                </p>
                <Button variant="outline" className="border-border/50 w-full">
                  Settings
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* FAQ */}
        <div className="space-y-6 mb-12">
          <Card className="card-cosmic p-8">
            <h2 className="text-2xl font-bold mb-6 text-accent">Frequently Asked</h2>
            
            <div className="space-y-6">
              <div>
                <h3 className="font-bold text-lg mb-2">Is my data encrypted?</h3>
                <p className="text-muted-foreground">
                  Yes. All data is encrypted with AES-256 at rest and TLS 1.3 in transit. Your password is hashed with bcrypt.
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-2">Can I delete my account?</h3>
                <p className="text-muted-foreground">
                  Yes. Deleting your account permanently removes all your data from our servers within 30 days.
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-2">Who has access to my data?</h3>
                <p className="text-muted-foreground">
                  Only you. Our team cannot access your data without explicit permission. We use automated backups for disaster recovery only.
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-2">How long do you keep my data?</h3>
                <p className="text-muted-foreground">
                  As long as your account is active. After deletion, data is purged within 30 days, with backups removed within 90 days.
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-2">Do you use my data for ads?</h3>
                <p className="text-muted-foreground">
                  Never. We don't have ads, and we don't sell or share data with advertisers. Our business model is subscription-based.
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* CTA */}
        <div className="text-center">
          <p className="text-muted-foreground mb-6">
            Questions about privacy? Contact us at privacy@nutrivision.app
          </p>
          <Button
            onClick={() => navigate("/dashboard")}
            className="btn-cosmic"
          >
            Back to Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
}
