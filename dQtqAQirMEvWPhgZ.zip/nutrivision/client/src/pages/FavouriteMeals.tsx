import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Heart, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function FavouriteMeals() {
  const { user, isAuthenticated } = useAuth();
  const [selectedMeal, setSelectedMeal] = useState<number | null>(null);

  const { data: favourites, isLoading } = trpc.diary.getFavouriteMeals.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const deleteMutation = trpc.diary.deleteFavouriteMeal.useMutation({
    onSuccess: () => {
      toast.success("Favourite meal removed");
      trpc.useUtils().diary.getFavouriteMeals.invalidate();
    },
    onError: () => {
      toast.error("Failed to remove favourite meal");
    },
  });

  const logMutation = trpc.diary.logMealFromFavourite.useMutation({
    onSuccess: () => {
      toast.success("Meal logged from favourite!");
      trpc.useUtils().diary.getDailySummary.invalidate();
    },
    onError: () => {
      toast.error("Failed to log meal");
    },
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center cosmic-bg">
        <Card className="p-8 text-center">
          <p className="text-lg mb-4">Please log in to view your favourite meals</p>
          <Button>Sign In</Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen cosmic-bg p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold cosmic-text mb-2">⭐ Favourite Meals</h1>
          <p className="text-cosmic-text-secondary">Quick-log your frequently eaten meals</p>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin">
              <div className="w-8 h-8 border-4 border-cosmic-accent border-t-transparent rounded-full"></div>
            </div>
          </div>
        ) : !favourites || favourites.length === 0 ? (
          <Card className="p-12 text-center">
            <Heart className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <p className="text-lg mb-4">No favourite meals yet</p>
            <p className="text-sm text-cosmic-text-secondary mb-6">
              Save meals from your food diary to quickly log them again
            </p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {favourites.map((meal: any) => (
              <Card
                key={meal.id}
                className="p-6 cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => setSelectedMeal(meal.id)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold cosmic-text">{meal.name}</h3>
                    {meal.description && (
                      <p className="text-sm text-cosmic-text-secondary mt-1">{meal.description}</p>
                    )}
                  </div>
                  <Heart className="w-5 h-5 text-cosmic-accent fill-cosmic-accent" />
                </div>

                <div className="grid grid-cols-2 gap-2 mb-4 text-sm">
                  <div>
                    <span className="text-cosmic-text-secondary">Calories:</span>
                    <p className="font-semibold">{Math.round(Number(meal.totalCalories))}</p>
                  </div>
                  <div>
                    <span className="text-cosmic-text-secondary">Protein:</span>
                    <p className="font-semibold">{Number(meal.totalProteinG || 0).toFixed(1)}g</p>
                  </div>
                  <div>
                    <span className="text-cosmic-text-secondary">Carbs:</span>
                    <p className="font-semibold">{Number(meal.totalCarbsG || 0).toFixed(1)}g</p>
                  </div>
                  <div>
                    <span className="text-cosmic-text-secondary">Fat:</span>
                    <p className="font-semibold">{Number(meal.totalFatG || 0).toFixed(1)}g</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="flex-1"
                    onClick={(e) => {
                      e.stopPropagation();
                      logMutation.mutate({ favouriteMealId: meal.id });
                    }}
                    disabled={logMutation.isPending}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Log Now
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteMutation.mutate({ favouriteMealId: meal.id });
                    }}
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
