import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Loader2, Plus, Camera, Utensils, TrendingUp, Heart } from "lucide-react";
import { format, addDays, subDays } from "date-fns";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

export default function Dashboard() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [activeTab, setActiveTab] = useState<'overview' | 'favourites'>('overview');

  const profile = trpc.profile.get.useQuery();
  const dailySummary = trpc.diary.getDailySummary.useQuery({ date: selectedDate });

  if (!user) {
    navigate("/");
    return null;
  }

  if (profile.isLoading || dailySummary.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 animate-spin text-accent" />
          <p className="text-foreground text-lg">Loading your nutrition data...</p>
        </div>
      </div>
    );
  }

  if (!profile.data) {
    navigate("/profile-setup");
    return null;
  }

  const summary = (dailySummary.data || {
    totalCalories: 0,
    totalProteinG: 0,
    totalCarbsG: 0,
    totalFatG: 0,
    totalFiberG: 0,
    totalAddedSugarsG: 0,
    totalNaturalSugarsG: 0,
    totalSodiumMg: 0,
    mealCount: 0,
    targets: null,
  }) as any;
  const targets = summary.targets;

  // Calculate percentages
  const caloriePercent = targets ? (summary.totalCalories / targets.calories) * 100 : 0;
  const proteinPercent = targets ? (summary.totalProteinG / targets.protein) * 100 : 0;
  const carbsPercent = targets ? (summary.totalCarbsG / targets.carbs) * 100 : 0;
  const fatPercent = targets ? (summary.totalFatG / targets.fat) * 100 : 0;

  // Macro breakdown for pie chart
  const macroData = [
    { name: "Protein", value: summary.totalProteinG, color: "#a78bfa" },
    { name: "Carbs", value: summary.totalCarbsG, color: "#60a5fa" },
    { name: "Fat", value: summary.totalFatG, color: "#f87171" },
  ];

  const NutritionRing = ({ value, max, label, color }: any) => {
    const percent = Math.min((value / max) * 100, 100);
    const circumference = 2 * Math.PI * 45;
    const offset = circumference - (percent / 100) * circumference;

    return (
      <div className="flex flex-col items-center">
        <div className="relative w-32 h-32">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
            <circle
              cx="60"
              cy="60"
              r="45"
              fill="none"
              stroke="currentColor"
              strokeWidth="8"
              className="text-muted"
            />
            <circle
              cx="60"
              cy="60"
              r="45"
              fill="none"
              stroke={color}
              strokeWidth="8"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              strokeLinecap="round"
              className="transition-all duration-500"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="text-2xl font-bold text-foreground">{Math.round(value)}</div>
            <div className="text-xs text-muted-foreground">/ {Math.round(max)}</div>
          </div>
        </div>
        <p className="mt-2 text-sm font-semibold text-foreground">{label}</p>
        <p className="text-xs text-muted-foreground">{Math.round(percent)}%</p>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background text-foreground pb-12">
      {/* Header */}
      <div className="border-b border-border/30 backdrop-blur-sm sticky top-0 z-10">
        <div className="container py-4 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold glow-text">Welcome, {user.name}</h1>
            <p className="text-muted-foreground">
              {format(selectedDate, "EEEE, MMMM d, yyyy")}
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => navigate("/fridge-scanner")}
              className="btn-cosmic flex items-center gap-2"
            >
              <Camera className="w-4 h-4" />
              Scan Fridge
            </Button>
            <Button
              onClick={() => navigate("/log-meal")}
              className="btn-cosmic flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Log Meal
            </Button>
          </div>
        </div>
      </div>

      <div className="container py-8 space-y-8">
        {/* Date Navigation */}
        <div className="flex items-center justify-center gap-4">
          <Button
            variant="outline"
            onClick={() => setSelectedDate(subDays(selectedDate, 1))}
            className="border-border/50"
          >
            ← Previous
          </Button>
          <span className="text-sm font-semibold text-muted-foreground min-w-32 text-center">
            {format(selectedDate, "MMM d")}
          </span>
          <Button
            variant="outline"
            onClick={() => setSelectedDate(addDays(selectedDate, 1))}
            disabled={addDays(selectedDate, 1) > new Date()}
            className="border-border/50"
          >
            Next →
          </Button>
        </div>

        {/* Calorie Summary */}
        <Card className="card-cosmic p-8">
          <h2 className="text-2xl font-bold mb-8 text-accent">Daily Summary</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <NutritionRing
              value={summary.totalCalories}
              max={targets?.calories || 2000}
              label="Calories"
              color="#8b5cf6"
            />
            <NutritionRing
              value={summary.totalProteinG}
              max={targets?.protein || 150}
              label="Protein (g)"
              color="#a78bfa"
            />
            <NutritionRing
              value={summary.totalCarbsG}
              max={targets?.carbs || 250}
              label="Carbs (g)"
              color="#60a5fa"
            />
            <NutritionRing
              value={summary.totalFatG}
              max={targets?.fat || 65}
              label="Fat (g)"
              color="#f87171"
            />
          </div>

          {/* Additional Nutrients */}
          <div className="mt-8 pt-8 border-t border-border/30 grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
              <p className="text-xs text-muted-foreground mb-1">Fiber</p>
              <p className="text-lg font-bold text-foreground">{Math.round(summary.totalFiberG)}g</p>
              <p className="text-xs text-muted-foreground">Target: {Math.round(targets?.fiber || 30)}g</p>
            </div>
            <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
              <p className="text-xs text-muted-foreground mb-1">Added Sugars</p>
              <p className="text-lg font-bold text-foreground">{Math.round(summary.totalAddedSugarsG)}g</p>
              <p className="text-xs text-muted-foreground">Limit: 25-36g</p>
            </div>
            <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
              <p className="text-xs text-muted-foreground mb-1">Natural Sugars</p>
              <p className="text-lg font-bold text-foreground">{Math.round(summary.totalNaturalSugarsG)}g</p>
              <p className="text-xs text-muted-foreground">From whole foods</p>
            </div>
            <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
              <p className="text-xs text-muted-foreground mb-1">Sodium</p>
              <p className="text-lg font-bold text-foreground">{Math.round(summary.totalSodiumMg)}mg</p>
              <p className="text-xs text-muted-foreground">Limit: 2300mg</p>
            </div>
          </div>
        </Card>

        {/* Macro Breakdown Chart */}
        {(summary.totalProteinG ?? 0) > 0 && (
          <Card className="card-cosmic p-8">
            <h3 className="text-xl font-bold mb-6 text-accent">Macro Distribution</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={macroData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${Math.round(value)}g`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {macroData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `${Math.round(value as number)}g`} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </Card>
        )}

        {/* Meals List */}
        {(summary.mealCount ?? 0) > 0 && (
          <Card className="card-cosmic p-8">
            <h3 className="text-xl font-bold mb-6 text-accent flex items-center gap-2">
              <Utensils className="w-5 h-5" />
              Meals Logged ({summary.mealCount})
            </h3>
            <p className="text-muted-foreground">
              View detailed meal breakdown in the Food Diary
            </p>
            <Button
              onClick={() => navigate("/diary")}
              className="mt-4 btn-cosmic"
            >
              View Diary
            </Button>
          </Card>
        )}

        {/* Empty State */}
        {(summary.mealCount ?? 0) === 0 && (
          <Card className="card-cosmic p-12 text-center">
            <Utensils className="w-12 h-12 text-accent mx-auto mb-4 opacity-50" />
            <h3 className="text-xl font-bold mb-2">No meals logged yet</h3>
            <p className="text-muted-foreground mb-6">
              Start by logging a meal or scanning your fridge for ingredient ideas
            </p>
            <div className="flex gap-4 justify-center">
              <Button
                onClick={() => navigate("/log-meal")}
                className="btn-cosmic"
              >
                Log Meal
              </Button>
              <Button
                onClick={() => navigate("/fridge-scanner")}
                variant="outline"
                className="border-border/50"
              >
                Scan Fridge
              </Button>
            </div>
          </Card>
        )}
      </div>

      {/* Footer with Privacy Link */}
      <footer className="border-t border-border/30 backdrop-blur-sm mt-20 relative z-10">
        <div className="container py-8 flex items-center justify-between text-sm text-muted-foreground">
          <p>
            NutriVision • Science • Compassion • Privacy
          </p>
          <button
            onClick={() => navigate("/privacy")}
            className="hover:text-accent transition-colors"
          >
            Privacy Policy
          </button>
        </div>
      </footer>
    </div>
  );
}
