import { useState, useRef } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Loader2, Camera, Check, X, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function FridgeScanner() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [detectedItems, setDetectedItems] = useState<Array<{
    name: string;
    confidence: number;
    quantity?: number;
    unit?: string;
    selected?: boolean;
  }>>([]);

  type DetectedItem = {
    name: string;
    confidence: number;
    quantity?: number;
    unit?: string;
    selected?: boolean;
  };

  const detectIngredients = trpc.fridgeScanner.detectIngredients.useMutation({
    onSuccess: (data) => {
      setDetectedItems(data.detectedItems.map((item: any) => ({ ...item, selected: true })));
      toast.success(`Found ${data.detectedItems.length} ingredients!`);
      setLoading(false);
    },
    onError: (error) => {
      toast.error(`Detection failed: ${error.message}`);
      setLoading(false);
    },
  });

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Preview
    const reader = new FileReader();
    reader.onload = (event) => {
      setImagePreview(event.target?.result as string);
    };
    reader.readAsDataURL(file);

    // Upload and detect
    setLoading(true);
    const base64 = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });

    detectIngredients.mutate({
      imageUrl: imagePreview || "",
      imageBase64: base64.split(",")[1],
    });
  };

  const toggleItem = (index: number) => {
    setDetectedItems((prev: DetectedItem[]) => {
      const updated = [...prev];
      if (updated[index]) {
        updated[index].selected = !updated[index].selected;
      }
      return updated;
    });
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return "text-green-400";
    if (confidence >= 0.6) return "text-yellow-400";
    return "text-orange-400";
  };

  const getConfidenceLabel = (confidence: number) => {
    if (confidence >= 0.8) return "High";
    if (confidence >= 0.6) return "Medium";
    return "Low";
  };

  return (
    <div className="min-h-screen bg-background text-foreground py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold glow-text mb-2">Scan Your Fridge</h1>
          <p className="text-muted-foreground">
            Take a photo and let AI detect what you have. You control what gets logged.
          </p>
        </div>

        {/* Image Upload */}
        {!imagePreview ? (
          <Card className="card-cosmic p-12 text-center">
            <Camera className="w-16 h-16 text-accent mx-auto mb-6 opacity-50" />
            <h3 className="text-2xl font-bold mb-4">Take a Photo</h3>
            <p className="text-muted-foreground mb-8">
              Point your camera at your fridge contents and snap a clear photo
            </p>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
            <Button
              onClick={() => fileInputRef.current?.click()}
              className="btn-cosmic"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Detecting...
                </>
              ) : (
                <>
                  <Camera className="w-4 h-4 mr-2" />
                  Choose Photo
                </>
              )}
            </Button>
          </Card>
        ) : (
          <div className="space-y-8">
            {/* Image Preview */}
            <Card className="card-cosmic p-6 overflow-hidden">
              <img
                src={imagePreview}
                alt="Fridge contents"
                className="w-full h-96 object-cover rounded-lg"
              />
            </Card>

            {/* Detected Items */}
            {detectedItems.length > 0 ? (
              <Card className="card-cosmic p-8">
                <h3 className="text-2xl font-bold mb-6 text-accent">
                  Detected Ingredients ({detectedItems.filter(i => i.selected).length} selected)
                </h3>

                <div className="space-y-3 mb-8">
                  {detectedItems.map((item: DetectedItem, index: number) => (
                    <div
                      key={index}
                      onClick={() => toggleItem(index)}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        item.selected
                          ? "border-accent/50 bg-accent/10"
                          : "border-muted/30 bg-muted/5 opacity-50"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h4 className="text-lg font-bold capitalize">{item.name}</h4>
                            <span
                              className={`text-xs font-semibold px-2 py-1 rounded-full ${getConfidenceColor(
                                item.confidence
                              )}`}
                            >
                              {getConfidenceLabel(item.confidence)} ({Math.round(item.confidence * 100)}%)
                            </span>
                          </div>
                          {item.quantity && (
                            <p className="text-sm text-muted-foreground">
                              ~{item.quantity} {item.unit}
                            </p>
                          )}
                        </div>
                        <div className="ml-4">
                          {item.selected ? (
                            <Check className="w-6 h-6 text-green-400" />
                          ) : (
                            <X className="w-6 h-6 text-muted-foreground" />
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Confidence Info */}
                <div className="p-4 rounded-lg bg-accent/5 border border-accent/20 mb-8 flex gap-3">
                  <AlertCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-muted-foreground">
                    <p className="font-semibold text-foreground mb-1">Confidence Scores</p>
                    <p>
                      Green = Very confident • Yellow = Somewhat confident • Orange = Less certain.
                      Click items to select/deselect before generating recipes.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button
                    onClick={() => {
                      setImagePreview(null);
                      setDetectedItems([]);
                    }}
                    variant="outline"
                    className="flex-1 border-border/50"
                  >
                    Take Another Photo
                  </Button>
                  <Button
                    onClick={() => {
                      const selected = detectedItems.filter(i => i.selected);
                      if (selected.length === 0) {
                        toast.error("Please select at least one ingredient");
                        return;
                      }
                      navigate("/recipe-generator", {
                        state: { ingredients: selected },
                      });
                    }}
                    className="flex-1 btn-cosmic"
                  >
                    Generate Recipe
                  </Button>
                </div>
              </Card>
            ) : (
              loading && (
                <Card className="card-cosmic p-12 text-center">
                  <Loader2 className="w-12 h-12 animate-spin text-accent mx-auto mb-4" />
                  <p className="text-lg text-muted-foreground">Analyzing your fridge...</p>
                </Card>
              )
            )}
          </div>
        )}
      </div>
    </div>
  );
}
