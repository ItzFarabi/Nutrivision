import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { trpc } from "@/lib/trpc";
import { Loader2, Heart } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function ProfileSetup() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    age: "",
    gender: "male" as "male" | "female" | "other",
    heightCm: "",
    weightKg: "",
    activityLevel: "moderate" as "sedentary" | "light" | "moderate" | "active" | "veryActive",
    dietaryGoal: "maintenance" as "maintenance" | "weightLoss" | "weightGain" | "muscleGain",
    dietaryRestrictions: [] as string[],
  });

  const restrictions = [
    { id: "vegan", label: "Vegan" },
    { id: "vegetarian", label: "Vegetarian" },
    { id: "gluten-free", label: "Gluten-Free" },
    { id: "dairy-free", label: "Dairy-Free" },
    { id: "nut-free", label: "Nut-Free" },
    { id: "keto", label: "Keto" },
    { id: "paleo", label: "Paleo" },
  ];

  const setupProfile = trpc.profile.setup.useMutation({
    onSuccess: (data) => {
      toast.success(`Welcome! Your daily target is ${data.dailyCalorieTarget} calories`);
      navigate("/dashboard");
    },
    onError: (error) => {
      toast.error(`Error: ${error.message}`);
      setLoading(false);
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (!formData.age || !formData.heightCm || !formData.weightKg) {
      toast.error("Please fill in all required fields");
      setLoading(false);
      return;
    }

    setupProfile.mutate({
      age: parseInt(formData.age),
      gender: formData.gender,
      heightCm: parseFloat(formData.heightCm),
      weightKg: parseFloat(formData.weightKg),
      activityLevel: formData.activityLevel,
      dietaryGoal: formData.dietaryGoal,
      dietaryRestrictions: formData.dietaryRestrictions.length > 0 ? formData.dietaryRestrictions : undefined,
    });
  };

  const toggleRestriction = (id: string) => {
    setFormData(prev => ({
      ...prev,
      dietaryRestrictions: prev.dietaryRestrictions.includes(id)
        ? prev.dietaryRestrictions.filter(r => r !== id)
        : [...prev.dietaryRestrictions, id],
    }));
  };

  return (
    <div className="min-h-screen bg-background text-foreground py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Heart className="w-8 h-8 text-accent glow-text-cyan" />
            <h1 className="text-4xl font-bold glow-text">Let's Get Started</h1>
          </div>
          <p className="text-lg text-muted-foreground">
            Tell us about yourself so we can personalize your nutrition targets
          </p>
        </div>

        <Card className="card-cosmic p-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Basic Info */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-accent">Basic Information</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="age" className="text-foreground font-semibold">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    min="13"
                    max="120"
                    placeholder="e.g., 28"
                    value={formData.age}
                    onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                    className="input-cosmic mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="gender" className="text-foreground font-semibold">Gender</Label>
                  <Select value={formData.gender} onValueChange={(value: any) => setFormData(prev => ({ ...prev, gender: value }))}>
                    <SelectTrigger className="input-cosmic mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="height" className="text-foreground font-semibold">Height (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="e.g., 175"
                    value={formData.heightCm}
                    onChange={(e) => setFormData(prev => ({ ...prev, heightCm: e.target.value }))}
                    className="input-cosmic mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="weight" className="text-foreground font-semibold">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="e.g., 75"
                    value={formData.weightKg}
                    onChange={(e) => setFormData(prev => ({ ...prev, weightKg: e.target.value }))}
                    className="input-cosmic mt-2"
                  />
                </div>
              </div>
            </div>

            {/* Lifestyle */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-accent">Lifestyle</h3>
              
              <div>
                <Label htmlFor="activity" className="text-foreground font-semibold">Activity Level</Label>
                <Select value={formData.activityLevel} onValueChange={(value: any) => setFormData(prev => ({ ...prev, activityLevel: value }))}>
                  <SelectTrigger className="input-cosmic mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sedentary">Sedentary (little exercise)</SelectItem>
                    <SelectItem value="light">Light (1-3 days/week)</SelectItem>
                    <SelectItem value="moderate">Moderate (3-5 days/week)</SelectItem>
                    <SelectItem value="active">Active (6-7 days/week)</SelectItem>
                    <SelectItem value="veryActive">Very Active (intense training)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="goal" className="text-foreground font-semibold">Dietary Goal</Label>
                <Select value={formData.dietaryGoal} onValueChange={(value: any) => setFormData(prev => ({ ...prev, dietaryGoal: value }))}>
                  <SelectTrigger className="input-cosmic mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="maintenance">Maintenance (keep weight stable)</SelectItem>
                    <SelectItem value="weightLoss">Weight Loss (15% deficit)</SelectItem>
                    <SelectItem value="weightGain">Weight Gain (10% surplus)</SelectItem>
                    <SelectItem value="muscleGain">Muscle Gain (10% surplus + high protein)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Dietary Restrictions */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-accent">Dietary Preferences (Optional)</h3>
              <div className="grid grid-cols-2 gap-3">
                {restrictions.map(restriction => (
                  <div key={restriction.id} className="flex items-center gap-2">
                    <Checkbox
                      id={restriction.id}
                      checked={formData.dietaryRestrictions.includes(restriction.id)}
                      onCheckedChange={() => toggleRestriction(restriction.id)}
                    />
                    <Label htmlFor={restriction.id} className="cursor-pointer text-foreground">
                      {restriction.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Submit */}
            <Button
              type="submit"
              disabled={loading}
              className="w-full btn-cosmic text-lg py-6"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Calculating Your Targets...
                </>
              ) : (
                "Create My Profile"
              )}
            </Button>

            <p className="text-sm text-muted-foreground text-center">
              Your targets are calculated using science-backed nutrition guidelines and will be personalized to your profile.
            </p>
          </form>
        </Card>
      </div>
    </div>
  );
}
