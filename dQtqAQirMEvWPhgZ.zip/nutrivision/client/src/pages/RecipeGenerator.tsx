import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Loader2, ChefHat, Clock, Users } from "lucide-react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

export default function RecipeGenerator() {
  const { user } = useAuth();
  const [location, navigate] = useLocation();
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [recipes, setRecipes] = useState<any[]>([]);

  useEffect(() => {
    // Get ingredients from location state or session storage
    const params = new URLSearchParams(location.split("?")[1]);
    const stored = sessionStorage.getItem("fridge_ingredients");
    if (stored) {
      setIngredients(JSON.parse(stored));
      sessionStorage.removeItem("fridge_ingredients");
    }
  }, [location]);

  const generateRecipes = trpc.recipes.generate.useMutation({
    onSuccess: (data) => {
      setRecipes(data.recipes);
      toast.success("Recipes generated!");
      setLoading(false);
    },
    onError: (error) => {
      toast.error(`Generation failed: ${error.message}`);
      setLoading(false);
    },
  });

  const handleGenerate = () => {
    if (ingredients.length === 0) {
      toast.error("Please add ingredients first");
      return;
    }

    setLoading(true);
    generateRecipes.mutate({
      ingredients: ingredients.map(i => typeof i === "string" ? i : (i as any).name),
      dietaryRestrictions: undefined,
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold glow-text mb-2 flex items-center gap-3">
            <ChefHat className="w-10 h-10" />
            Recipe Ideas
          </h1>
          <p className="text-muted-foreground">
            Turn your ingredients into delicious, personalized recipes
          </p>
        </div>

        {/* Ingredients List */}
        {ingredients.length > 0 && (
          <Card className="card-cosmic p-6 mb-8">
            <h3 className="text-lg font-bold mb-4 text-accent">Your Ingredients</h3>
            <div className="flex flex-wrap gap-2 mb-6">
              {ingredients.map((ing: any, idx: number) => (
                <div
                  key={idx}
                  className="px-4 py-2 rounded-full bg-accent/20 border border-accent/50 text-sm font-medium"
                >
                  {typeof ing === "string" ? ing : ing?.name}
                </div>
              ))}
            </div>
            <Button
              onClick={() => navigate("/fridge-scanner")}
              variant="outline"
              className="border-border/50"
            >
              Scan Different Ingredients
            </Button>
          </Card>
        )}

        {/* Generate Button */}
        {!loading && recipes.length === 0 && (
          <Card className="card-cosmic p-12 text-center mb-8">
            <ChefHat className="w-16 h-16 text-accent mx-auto mb-6 opacity-50" />
            <h3 className="text-2xl font-bold mb-4">Ready to Cook?</h3>
            <p className="text-muted-foreground mb-8">
              AI will create personalized recipes based on your ingredients and dietary preferences
            </p>
            <Button
              onClick={handleGenerate}
              className="btn-cosmic"
              disabled={loading || ingredients.length === 0}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <ChefHat className="w-4 h-4 mr-2" />
                  Generate Recipes
                </>
              )}
            </Button>
          </Card>
        )}

        {/* Loading State */}
        {loading && (
          <Card className="card-cosmic p-12 text-center">
            <Loader2 className="w-12 h-12 animate-spin text-accent mx-auto mb-4" />
            <p className="text-lg text-muted-foreground">Creating personalized recipes...</p>
          </Card>
        )}

        {/* Recipes Display */}
        {recipes.length > 0 && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-accent">
                {recipes.length} Recipe{recipes.length !== 1 ? "s" : ""} Found
              </h2>
              <Button
                onClick={handleGenerate}
                disabled={loading}
                className="btn-cosmic"
              >
                Generate More
              </Button>
            </div>

            {recipes.map((recipe, idx) => (
              <Card key={idx} className="card-cosmic p-8 space-y-6">
                {/* Recipe Header */}
                <div>
                  <h3 className="text-3xl font-bold mb-2 text-accent">{recipe.title}</h3>
                  <p className="text-muted-foreground">{recipe.description}</p>
                </div>

                {/* Meta Info */}
                <div className="grid grid-cols-3 gap-4 py-6 border-y border-border/30">
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-accent" />
                    <div>
                      <p className="text-xs text-muted-foreground">Prep Time</p>
                      <p className="font-semibold">{recipe.prepTime}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-accent" />
                    <div>
                      <p className="text-xs text-muted-foreground">Cook Time</p>
                      <p className="font-semibold">{recipe.cookTime}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-accent" />
                    <div>
                      <p className="text-xs text-muted-foreground">Servings</p>
                      <p className="font-semibold">{recipe.servings}</p>
                    </div>
                  </div>
                </div>

                {/* Nutrition Info */}
                <div>
                  <h4 className="font-bold text-accent mb-4">Per Serving</h4>
                  <div className="grid grid-cols-4 gap-4">
                    <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
                      <p className="text-xs text-muted-foreground mb-1">Calories</p>
                      <p className="text-2xl font-bold">{recipe.nutrition.calories}</p>
                    </div>
                    <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
                      <p className="text-xs text-muted-foreground mb-1">Protein</p>
                      <p className="text-2xl font-bold">{recipe.nutrition.protein}g</p>
                    </div>
                    <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
                      <p className="text-xs text-muted-foreground mb-1">Carbs</p>
                      <p className="text-2xl font-bold">{recipe.nutrition.carbs}g</p>
                    </div>
                    <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
                      <p className="text-xs text-muted-foreground mb-1">Fat</p>
                      <p className="text-2xl font-bold">{recipe.nutrition.fat}g</p>
                    </div>
                  </div>
                </div>

                {/* Ingredients */}
                <div>
                  <h4 className="font-bold text-accent mb-4">Ingredients</h4>
                  <ul className="space-y-2">
                    {recipe.ingredients.map((ing: string, i: number) => (
                      <li key={i} className="flex items-start gap-3 text-muted-foreground">
                        <span className="text-accent font-bold mt-1">•</span>
                        <span>{ing}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Instructions */}
                <div>
                  <h4 className="font-bold text-accent mb-4">Instructions</h4>
                  <div className="space-y-4">
                    <Streamdown>{recipe.instructions}</Streamdown>
                  </div>
                </div>

                {/* Log Meal Button */}
                <Button
                  onClick={() => {
                    toast.success("Recipe saved! Ready to log this meal?");
                    navigate("/log-meal", { state: { recipe } });
                  }}
                  className="w-full btn-cosmic"
                >
                  Log This Meal
                </Button>
              </Card>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!loading && recipes.length === 0 && ingredients.length === 0 && (
          <Card className="card-cosmic p-12 text-center">
            <ChefHat className="w-12 h-12 text-accent mx-auto mb-4 opacity-50" />
            <h3 className="text-xl font-bold mb-2">No Ingredients Yet</h3>
            <p className="text-muted-foreground mb-6">
              Scan your fridge or add ingredients manually to get recipe ideas
            </p>
            <Button
              onClick={() => navigate("/fridge-scanner")}
              className="btn-cosmic"
            >
              Scan Fridge
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}
