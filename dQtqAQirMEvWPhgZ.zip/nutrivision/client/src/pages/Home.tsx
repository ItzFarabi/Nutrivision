import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { Loader2, Zap, Brain, Heart, Lock, Sparkles } from "lucide-react";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (isAuthenticated && !loading) {
      navigate("/dashboard");
    }
  }, [isAuthenticated, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 animate-spin text-accent" />
          <p className="text-foreground text-lg">Initializing NutriVision...</p>
        </div>
      </div>
    );
  }

  if (isAuthenticated) {
    return null; // Will redirect to dashboard
  }

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
      {/* Hero Section */}
      <div className="relative z-10">
        <nav className="border-b border-border/30 backdrop-blur-sm">
          <div className="container flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Sparkles className="w-8 h-8 text-accent glow-text-cyan" />
              <h1 className="text-2xl font-bold glow-text">NutriVision</h1>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => window.location.href = getLoginUrl()}
                variant="outline"
                className="border-border/50"
              >
                Sign In
              </Button>
              <Button
                onClick={() => window.location.href = getLoginUrl()}
                className="btn-cosmic"
              >
                Get Started
              </Button>
            </div>
          </div>
        </nav>

        {/* Hero Content */}
        <div className="container py-20 relative">
          <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-5xl md:text-6xl font-bold mb-4 glow-text leading-tight">
            Track Food.
            <br />
            <span className="text-accent">Not Guilt.</span>
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Scan your fridge. Get recipes. Hit your goals. No shame, no rules—just real nutrition.
          </p>
            <Button
              onClick={() => window.location.href = getLoginUrl()}
              size="lg"
              className="btn-cosmic text-lg px-8 py-6"
            >
              Begin Your Journey
            </Button>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="container py-20 relative z-10">
        <h3 className="text-3xl font-bold text-center mb-12 glow-text">
          Why NutriVision?
        </h3>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Feature 1 */}
          <Card className="card-cosmic p-6 group hover:scale-105 transition-transform duration-300">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-accent/10 group-hover:bg-accent/20 transition-colors">
                <Brain className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h4 className="text-lg font-bold mb-2">Scan & Detect</h4>
                <p className="text-sm text-muted-foreground">
                  Snap your fridge. AI finds ingredients. You decide what counts.
                </p>
              </div>
            </div>
          </Card>

          {/* Feature 2 */}
          <Card className="card-cosmic p-6 group hover:scale-105 transition-transform duration-300">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-accent/10 group-hover:bg-accent/20 transition-colors">
                <Zap className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h4 className="text-lg font-bold mb-2">Your Numbers</h4>
                <p className="text-sm text-muted-foreground">
                  Calorie & macro targets built just for you. Science-backed, not generic.
                </p>
              </div>
            </div>
          </Card>

          {/* Feature 3 */}
          <Card className="card-cosmic p-6 group hover:scale-105 transition-transform duration-300">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-accent/10 group-hover:bg-accent/20 transition-colors">
                <Heart className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h4 className="text-lg font-bold mb-2">Celebrate Wins</h4>
                <p className="text-sm text-muted-foreground">
                  No guilt trips. No punishment. Just genuine support.
                </p>
              </div>
            </div>
          </Card>

          {/* Feature 4 */}
          <Card className="card-cosmic p-6 group hover:scale-105 transition-transform duration-300">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-accent/10 group-hover:bg-accent/20 transition-colors">
                <Sparkles className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h4 className="text-lg font-bold mb-2">Recipe Ideas</h4>
                <p className="text-sm text-muted-foreground">
                  Turn what you have into meals that fit your goals.
                </p>
              </div>
            </div>
          </Card>

          {/* Feature 5 */}
          <Card className="card-cosmic p-6 group hover:scale-105 transition-transform duration-300">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-accent/10 group-hover:bg-accent/20 transition-colors">
                <Lock className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h4 className="text-lg font-bold mb-2">Your Data, Your Rules</h4>
                <p className="text-sm text-muted-foreground">
                  No third-party sharing. Full control. Always private.
                </p>
              </div>
            </div>
          </Card>

          {/* Feature 6 */}
          <Card className="card-cosmic p-6 group hover:scale-105 transition-transform duration-300">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-accent/10 group-hover:bg-accent/20 transition-colors">
                <Zap className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h4 className="text-lg font-bold mb-2">Real Measurements</h4>
                <p className="text-sm text-muted-foreground">
                  Grams & ml. No more "serving size" confusion.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* CTA Section */}
      <div className="container py-20 relative z-10">
        <Card className="card-cosmic p-12 text-center">
          <h3 className="text-3xl font-bold mb-4 glow-text">
            Start Tracking Today
          </h3>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            No credit card. No judgment. Just real nutrition tracking.
          </p>
          <Button
            onClick={() => window.location.href = getLoginUrl()}
            size="lg"
            className="btn-cosmic text-lg px-8 py-6"
          >
            Get Started Free
          </Button>
        </Card>
      </div>

      {/* Footer */}
      <footer className="border-t border-border/30 backdrop-blur-sm mt-20 relative z-10">
        <div className="container py-8 text-center text-sm text-muted-foreground">
          <p>
            NutriVision • Science • Compassion • Privacy
          </p>
        </div>
      </footer>
    </div>
  );
}
