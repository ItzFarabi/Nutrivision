import { useEffect, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Check, Loader2, Zap } from "lucide-react";
import { toast } from "sonner";

export default function Subscription() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [loading, setLoading] = useState(false);

  const subscriptionStatus = trpc.subscription.getDetails.useQuery();
  const createCheckout = trpc.subscription.createCheckoutSession.useQuery(
    undefined,
    { enabled: false }
  );

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("subscription") === "success") {
      toast.success("Subscription activated! Welcome to NutriVision Pro.");
      navigate("/dashboard");
    }
    if (params.get("cancelled") === "true") {
      toast.info("Checkout cancelled");
    }
  }, [navigate]);

  const handleSubscribe = async () => {
    setLoading(true);
    try {
      const result = await createCheckout.refetch();
      if (result.data?.checkoutUrl) {
        window.open(result.data.checkoutUrl, "_blank");
      }
    } catch (error) {
      toast.error("Failed to start checkout");
    } finally {
      setLoading(false);
    }
  };

  const isPro = subscriptionStatus.data?.status === "pro";
  const isOwner = subscriptionStatus.data?.isOwner;

  return (
    <div className="min-h-screen bg-background text-foreground py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-12">
          <h1 className="text-4xl font-bold glow-text mb-2">NutriVision Pro</h1>
          <p className="text-lg text-muted-foreground">
            Unlock advanced recipes and personalized nutrition insights
          </p>
        </div>

        {/* Current Status */}
        {subscriptionStatus.data && (
          <Card className="card-cosmic p-8 mb-12">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold mb-2">Your Plan</h2>
                <p className="text-muted-foreground">
                  {isOwner ? (
                    <span className="text-accent">Lifetime Free Access</span>
                  ) : isPro ? (
                    <span className="text-accent">Pro Subscriber</span>
                  ) : subscriptionStatus.data.status === "trial" ? (
                    <span>
                      Free Trial (expires{" "}
                      {subscriptionStatus.data.trialEndDate
                        ? new Date(subscriptionStatus.data.trialEndDate).toLocaleDateString()
                        : "soon"}
                      )
                    </span>
                  ) : (
                    <span>Free Plan</span>
                  )}
                </p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-accent mb-2">
                  {isOwner ? "∞" : isPro ? "£8" : "Free"}
                </div>
                {!isOwner && !isPro && <p className="text-sm text-muted-foreground">/month</p>}
              </div>
            </div>
          </Card>
        )}

        {/* Pricing Comparison */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Free Plan */}
          <Card className="card-cosmic p-8">
            <h3 className="text-2xl font-bold mb-6">Free Plan</h3>
            <div className="space-y-4 mb-8">
              <Feature included={true}>Daily nutrition tracking</Feature>
              <Feature included={true}>Fridge scanner with AI detection</Feature>
              <Feature included={true}>Basic recipes</Feature>
              <Feature included={false}>Advanced recipes</Feature>
              <Feature included={true}>Meal history</Feature>
              <Feature included={true}>Privacy controls</Feature>
            </div>
            <Button variant="outline" className="w-full border-border/50" disabled>
              Current Plan
            </Button>
          </Card>

          {/* Pro Plan */}
          <Card className="card-cosmic p-8 border-accent/50 relative">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2">
              <span className="bg-accent text-background px-4 py-1 rounded-full text-sm font-bold flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Recommended
              </span>
            </div>
            <h3 className="text-2xl font-bold mb-2">Pro Plan</h3>
            <div className="text-3xl font-bold text-accent mb-6">£8<span className="text-lg">/month</span></div>
            <div className="space-y-4 mb-8">
              <Feature included={true}>Daily nutrition tracking</Feature>
              <Feature included={true}>Fridge scanner with AI detection</Feature>
              <Feature included={true}>Basic recipes</Feature>
              <Feature included={true}>Advanced recipes</Feature>
              <Feature included={true}>Meal history</Feature>
              <Feature included={true}>Privacy controls</Feature>
            </div>
            {isOwner ? (
              <Button className="w-full btn-cosmic" disabled>
                Owner - Lifetime Free
              </Button>
            ) : isPro ? (
              <Button className="w-full btn-cosmic" disabled>
                ✓ Active Subscription
              </Button>
            ) : (
              <Button
                onClick={handleSubscribe}
                disabled={loading}
                className="w-full btn-cosmic"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Starting Checkout...
                  </>
                ) : (
                  "Start 7-Day Free Trial"
                )}
              </Button>
            )}
            <p className="text-xs text-muted-foreground text-center mt-4">
              Then £8/month. Cancel anytime.
            </p>
          </Card>
        </div>

        {/* Trial Info */}
        {subscriptionStatus.data?.status === "trial" && (
          <Card className="card-cosmic p-6 mb-12 border-accent/30 bg-accent/5">
            <h3 className="font-bold text-lg mb-2">Your Free Trial</h3>
            <p className="text-muted-foreground mb-4">
              You have full access to all Pro features until{" "}
              <span className="text-accent font-semibold">
                {subscriptionStatus.data.trialEndDate
                  ? new Date(subscriptionStatus.data.trialEndDate).toLocaleDateString()
                  : "soon"}
              </span>
              . After that, your plan will revert to Free unless you subscribe.
            </p>
            <Button
              onClick={handleSubscribe}
              disabled={loading}
              className="btn-cosmic"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Starting Checkout...
                </>
              ) : (
                "Subscribe Now"
              )}
            </Button>
          </Card>
        )}

        {/* FAQ */}
        <Card className="card-cosmic p-8">
          <h2 className="text-2xl font-bold mb-6 text-accent">Questions?</h2>
          <div className="space-y-6">
            <div>
              <h3 className="font-bold text-lg mb-2">Can I cancel anytime?</h3>
              <p className="text-muted-foreground">
                Yes! Cancel your subscription anytime from your account settings. No questions asked.
              </p>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-2">What happens after my trial?</h3>
              <p className="text-muted-foreground">
                If you don't subscribe, your account will revert to the Free plan. You'll keep all your meal history and data.
              </p>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-2">Is there a refund policy?</h3>
              <p className="text-muted-foreground">
                We offer a 14-day money-back guarantee. Contact support@nutrivision.app for refunds.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

function Feature({ included, children }: { included: boolean; children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-3">
      <div
        className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
          included ? "bg-accent/20 border border-accent" : "bg-muted/20 border border-border/30"
        }`}
      >
        {included && <Check className="w-3 h-3 text-accent" />}
      </div>
      <span className={included ? "text-foreground" : "text-muted-foreground line-through"}>
        {children}
      </span>
    </div>
  );
}
