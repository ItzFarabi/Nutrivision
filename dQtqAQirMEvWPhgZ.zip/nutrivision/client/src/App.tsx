import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Home from "@/pages/Home";
import ProfileSetup from "@/pages/ProfileSetup";
import Dashboard from "@/pages/Dashboard";
import FridgeScanner from "@/pages/FridgeScanner";
import RecipeGenerator from "@/pages/RecipeGenerator";
import LogMeal from "@/pages/LogMeal";
import Privacy from "@/pages/Privacy";
import Subscription from "@/pages/Subscription";
import FavouriteMeals from "@/pages/FavouriteMeals";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/profile-setup"} component={ProfileSetup} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/fridge-scanner"} component={FridgeScanner} />
      <Route path={"/recipe-generator"} component={RecipeGenerator} />
      <Route path={"/log-meal"} component={LogMeal} />
      <Route path={"/privacy"} component={Privacy} />
      <Route path={"/subscription"} component={Subscription} />
      <Route path={"/favourite-meals"} component={FavouriteMeals} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
