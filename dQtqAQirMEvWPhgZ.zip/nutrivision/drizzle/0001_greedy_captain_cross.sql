CREATE TABLE `fridgePhotos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`photoUrl` varchar(512) NOT NULL,
	`photoKey` varchar(255) NOT NULL,
	`detectedIngredients` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `fridgePhotos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ingredients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`mealId` int NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`quantity` decimal(8,2) NOT NULL,
	`unit` varchar(50) NOT NULL,
	`caloriesPerUnit` decimal(8,2),
	`totalCalories` decimal(8,2) NOT NULL,
	`proteinG` decimal(8,2),
	`carbsG` decimal(8,2),
	`fatG` decimal(8,2),
	`fiberG` decimal(8,2),
	`addedSugarsG` decimal(8,2),
	`naturalSugarsG` decimal(8,2),
	`sodiumMg` decimal(8,2),
	`detectionConfidence` decimal(3,2),
	`detectionMethod` enum('manual','aiDetected','recipe'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ingredients_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mealPhotos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`mealId` int NOT NULL,
	`userId` int NOT NULL,
	`photoUrl` varchar(512) NOT NULL,
	`photoKey` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mealPhotos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `meals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`mealType` enum('breakfast','lunch','dinner','snack') NOT NULL,
	`date` date NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `meals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `privacySettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`allowAnalytics` boolean DEFAULT false,
	`allowDataExport` boolean DEFAULT true,
	`dataRetentionDays` int DEFAULT 365,
	`lastPrivacyReviewDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `privacySettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `privacySettings_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `recipes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`fridgePhotoId` int,
	`title` varchar(255) NOT NULL,
	`description` text,
	`instructions` longtext NOT NULL,
	`servings` int DEFAULT 1,
	`prepTimeMinutes` int,
	`cookTimeMinutes` int,
	`ingredients` json,
	`caloriesPerServing` decimal(8,2),
	`proteinPerServingG` decimal(8,2),
	`carbsPerServingG` decimal(8,2),
	`fatPerServingG` decimal(8,2),
	`fiberPerServingG` decimal(8,2),
	`addedSugarsPerServingG` decimal(8,2),
	`naturalSugarsPerServingG` decimal(8,2),
	`dietaryTags` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `recipes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userProfiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`age` int,
	`gender` enum('male','female','other'),
	`heightCm` decimal(5,1),
	`weightKg` decimal(5,1),
	`activityLevel` enum('sedentary','light','moderate','active','veryActive') DEFAULT 'moderate',
	`dietaryGoal` enum('maintenance','weightLoss','weightGain','muscleGain') DEFAULT 'maintenance',
	`dietaryRestrictions` json,
	`dailyCalorieTarget` int,
	`dailyProteinG` decimal(6,1),
	`dailyCarbsG` decimal(6,1),
	`dailyFatG` decimal(6,1),
	`dailyFiberG` decimal(6,1),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userProfiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `userProfiles_userId_unique` UNIQUE(`userId`)
);
