import { 
  int, 
  mysqlEnum, 
  mysqlTable, 
  text, 
  timestamp, 
  varchar,
  decimal,
  boolean,
  json,
  date,
  longtext
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  subscriptionStatus: mysqlEnum("subscriptionStatus", ["free", "trial", "pro", "cancelled"]).default("free").notNull(),
  trialEndDate: timestamp("trialEndDate"),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User nutrition profile with personalized targets based on health data.
 * Targets are calculated using public health guidelines (e.g., NHS, USDA).
 */
export const userProfiles = mysqlTable("userProfiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  age: int("age"),
  gender: mysqlEnum("gender", ["male", "female", "other"]),
  heightCm: decimal("heightCm", { precision: 5, scale: 1 }), // cm
  weightKg: decimal("weightKg", { precision: 5, scale: 1 }), // kg
  activityLevel: mysqlEnum("activityLevel", ["sedentary", "light", "moderate", "active", "veryActive"]).default("moderate"),
  dietaryGoal: mysqlEnum("dietaryGoal", ["maintenance", "weightLoss", "weightGain", "muscleGain"]).default("maintenance"),
  dietaryRestrictions: json("dietaryRestrictions").$type<string[]>(), // vegan, vegetarian, gluten-free, etc.
  dailyCalorieTarget: int("dailyCalorieTarget"), // calculated
  dailyProteinG: decimal("dailyProteinG", { precision: 6, scale: 1 }),
  dailyCarbsG: decimal("dailyCarbsG", { precision: 6, scale: 1 }),
  dailyFatG: decimal("dailyFatG", { precision: 6, scale: 1 }),
  dailyFiberG: decimal("dailyFiberG", { precision: 6, scale: 1 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = typeof userProfiles.$inferInsert;

/**
 * Meal entries in the daily food diary.
 */
export const meals = mysqlTable("meals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  mealType: mysqlEnum("mealType", ["breakfast", "lunch", "dinner", "snack"]).notNull(),
  date: date("date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Meal = typeof meals.$inferSelect;
export type InsertMeal = typeof meals.$inferInsert;

/**
 * Individual ingredients logged in meals.
 * Each ingredient has weight-based quantities and nutritional data.
 */
export const ingredients = mysqlTable("ingredients", {
  id: int("id").autoincrement().primaryKey(),
  mealId: int("mealId").notNull(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  quantity: decimal("quantity", { precision: 8, scale: 2 }).notNull(), // numeric value
  unit: varchar("unit", { length: 50 }).notNull(), // g, ml, oz, cup, tbsp, etc.
  caloriesPerUnit: decimal("caloriesPerUnit", { precision: 8, scale: 2 }), // calories per 100g or per unit
  totalCalories: decimal("totalCalories", { precision: 8, scale: 2 }).notNull(),
  proteinG: decimal("proteinG", { precision: 8, scale: 2 }),
  carbsG: decimal("carbsG", { precision: 8, scale: 2 }),
  fatG: decimal("fatG", { precision: 8, scale: 2 }),
  fiberG: decimal("fiberG", { precision: 8, scale: 2 }),
  addedSugarsG: decimal("addedSugarsG", { precision: 8, scale: 2 }), // distinguish from natural sugars
  naturalSugarsG: decimal("naturalSugarsG", { precision: 8, scale: 2 }),
  sodiumMg: decimal("sodiumMg", { precision: 8, scale: 2 }),
  detectionConfidence: decimal("detectionConfidence", { precision: 3, scale: 2 }), // 0.0 to 1.0, AI confidence
  detectionMethod: mysqlEnum("detectionMethod", ["manual", "aiDetected", "recipe"]), // how it was logged
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Ingredient = typeof ingredients.$inferSelect;
export type InsertIngredient = typeof ingredients.$inferInsert;

/**
 * Fridge photos uploaded by users for ingredient detection.
 * Photos are stored in S3, URLs saved here for retrieval and visual journal.
 */
export const fridgePhotos = mysqlTable("fridgePhotos", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  photoUrl: varchar("photoUrl", { length: 512 }).notNull(), // S3 storage URL
  photoKey: varchar("photoKey", { length: 255 }).notNull(), // S3 storage key for reference
  detectedIngredients: json("detectedIngredients").$type<Array<{
    name: string;
    confidence: number;
    quantity?: number;
    unit?: string;
  }>>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type FridgePhoto = typeof fridgePhotos.$inferSelect;
export type InsertFridgePhoto = typeof fridgePhotos.$inferInsert;

/**
 * Generated recipes from detected fridge ingredients.
 * Recipes are personalized to user's dietary profile and restrictions.
 */
export const recipes = mysqlTable("recipes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  fridgePhotoId: int("fridgePhotoId"),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  instructions: longtext("instructions").notNull(), // step-by-step instructions
  servings: int("servings").default(1),
  prepTimeMinutes: int("prepTimeMinutes"),
  cookTimeMinutes: int("cookTimeMinutes"),
  ingredients: json("ingredients").$type<Array<{
    name: string;
    quantity: number;
    unit: string;
  }>>(),
  caloriesPerServing: decimal("caloriesPerServing", { precision: 8, scale: 2 }),
  proteinPerServingG: decimal("proteinPerServingG", { precision: 8, scale: 2 }),
  carbsPerServingG: decimal("carbsPerServingG", { precision: 8, scale: 2 }),
  fatPerServingG: decimal("fatPerServingG", { precision: 8, scale: 2 }),
  fiberPerServingG: decimal("fiberPerServingG", { precision: 8, scale: 2 }),
  addedSugarsPerServingG: decimal("addedSugarsPerServingG", { precision: 8, scale: 2 }),
  naturalSugarsPerServingG: decimal("naturalSugarsPerServingG", { precision: 8, scale: 2 }),
  dietaryTags: json("dietaryTags").$type<string[]>(), // vegan, gluten-free, etc.
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Recipe = typeof recipes.$inferSelect;
export type InsertRecipe = typeof recipes.$inferInsert;

/**
 * Meal photos for visual food journal.
 * Users can attach photos to logged meals for reference and tracking.
 */
export const mealPhotos = mysqlTable("mealPhotos", {
  id: int("id").autoincrement().primaryKey(),
  mealId: int("mealId").notNull(),
  userId: int("userId").notNull(),
  photoUrl: varchar("photoUrl", { length: 512 }).notNull(), // S3 storage URL
  photoKey: varchar("photoKey", { length: 255 }).notNull(), // S3 storage key
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MealPhoto = typeof mealPhotos.$inferSelect;
export type InsertMealPhoto = typeof mealPhotos.$inferInsert;

/**
 * Privacy and data handling preferences.
 * Tracks user consent for data collection and sharing.
 */
export const privacySettings = mysqlTable("privacySettings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  allowAnalytics: boolean("allowAnalytics").default(false),
  allowDataExport: boolean("allowDataExport").default(true),
  dataRetentionDays: int("dataRetentionDays").default(365), // 0 = indefinite
  lastPrivacyReviewDate: timestamp("lastPrivacyReviewDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PrivacySettings = typeof privacySettings.$inferSelect;
export type InsertPrivacySettings = typeof privacySettings.$inferInsert;

/**
 * Favourite meals saved by users for quick logging.
 * Users can save frequently eaten meals and log them instantly.
 */
export const favouriteMeals = mysqlTable("favouriteMeals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  mealType: mysqlEnum("mealType", ["breakfast", "lunch", "dinner", "snack"]),
  ingredients: json("ingredients").$type<Array<{
    name: string;
    quantity: number;
    unit: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  }>>(). notNull(),
  totalCalories: decimal("totalCalories", { precision: 8, scale: 2 }).notNull(),
  totalProteinG: decimal("totalProteinG", { precision: 8, scale: 2 }),
  totalCarbsG: decimal("totalCarbsG", { precision: 8, scale: 2 }),
  totalFatG: decimal("totalFatG", { precision: 8, scale: 2 }),
  photoUrl: varchar("photoUrl", { length: 512 }),
  photoKey: varchar("photoKey", { length: 255 }),
  timesLogged: int("timesLogged").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FavouriteMeal = typeof favouriteMeals.$inferSelect;
export type InsertFavouriteMeal = typeof favouriteMeals.$inferInsert;
