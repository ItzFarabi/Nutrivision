CREATE TABLE `favouriteMeals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`mealType` enum('breakfast','lunch','dinner','snack'),
	`ingredients` json NOT NULL,
	`totalCalories` decimal(8,2) NOT NULL,
	`totalProteinG` decimal(8,2),
	`totalCarbsG` decimal(8,2),
	`totalFatG` decimal(8,2),
	`photoUrl` varchar(512),
	`photoKey` varchar(255),
	`timesLogged` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `favouriteMeals_id` PRIMARY KEY(`id`)
);
