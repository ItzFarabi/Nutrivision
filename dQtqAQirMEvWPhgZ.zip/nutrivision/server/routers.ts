import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";
import * as db from "./db";
import { subscriptionRouter } from "./subscription-router";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  /**
   * Subscription management and billing
   */
  subscription: subscriptionRouter,

  /**
   * User profile management with personalized nutrition targets.
   */
  profile: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserProfile(ctx.user.id);
    }),

    setup: protectedProcedure
      .input(z.object({
        age: z.number().int().min(13).max(120),
        gender: z.enum(["male", "female", "other"]),
        heightCm: z.number().positive(),
        weightKg: z.number().positive(),
        activityLevel: z.enum(["sedentary", "light", "moderate", "active", "veryActive"]),
        dietaryGoal: z.enum(["maintenance", "weightLoss", "weightGain", "muscleGain"]),
        dietaryRestrictions: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Calculate personalized targets based on Harris-Benedict equation
        const heightM = input.heightCm / 100;
        const weight = input.weightKg;
        const age = input.age;

        let bmr: number;
        if (input.gender === "male") {
          bmr = 88.362 + (13.397 * weight) + (4.799 * input.heightCm) - (5.677 * age);
        } else {
          bmr = 447.593 + (9.247 * weight) + (3.098 * input.heightCm) - (4.330 * age);
        }

        // Activity multiplier
        const activityMultipliers: Record<string, number> = {
          sedentary: 1.2,
          light: 1.375,
          moderate: 1.55,
          active: 1.725,
          veryActive: 1.9,
        };

        let tdee = bmr * activityMultipliers[input.activityLevel];

        // Adjust for goal
        if (input.dietaryGoal === "weightLoss") {
          tdee *= 0.85; // 15% deficit
        } else if (input.dietaryGoal === "weightGain") {
          tdee *= 1.1; // 10% surplus
        } else if (input.dietaryGoal === "muscleGain") {
          tdee *= 1.1; // 10% surplus
        }

        // Macro targets (% of calories)
        let proteinPercent = 0.3;
        let carbsPercent = 0.45;
        let fatPercent = 0.25;

        if (input.dietaryGoal === "muscleGain") {
          proteinPercent = 0.35;
          carbsPercent = 0.45;
          fatPercent = 0.2;
        }

        const dailyProteinG = (tdee * proteinPercent) / 4;
        const dailyCarbsG = (tdee * carbsPercent) / 4;
        const dailyFatG = (tdee * fatPercent) / 9;
        const dailyFiberG = weight * 0.014; // ~14mg per kg body weight

        await db.upsertUserProfile(ctx.user.id, {
          age: input.age,
          gender: input.gender as any,
          heightCm: input.heightCm as any,
          weightKg: weight as any,
          activityLevel: input.activityLevel as any,
          dietaryGoal: input.dietaryGoal as any,
          dietaryRestrictions: input.dietaryRestrictions as any,
          dailyCalorieTarget: Math.round(tdee),
          dailyProteinG: dailyProteinG as any,
          dailyCarbsG: dailyCarbsG as any,
          dailyFatG: dailyFatG as any,
          dailyFiberG: dailyFiberG as any,
        });

        return {
          success: true,
          dailyCalorieTarget: Math.round(tdee),
          dailyProteinG: Math.round(dailyProteinG),
          dailyCarbsG: Math.round(dailyCarbsG),
          dailyFatG: Math.round(dailyFatG),
        };
      }),
  }),

  /**
   * Food diary and meal logging.
   */
  diary: router({
    getMealsByDate: protectedProcedure
      .input(z.object({ date: z.date() }))
      .query(async ({ ctx, input }) => {
        const meals = await db.getMealsByDate(ctx.user.id, input.date);
        const mealsWithIngredients = await Promise.all(
          meals.map(async (meal) => ({
            ...meal,
            ingredients: await db.getMealIngredients(meal.id),
          }))
        );
        return mealsWithIngredients;
      }),

    getDailySummary: protectedProcedure
      .input(z.object({ date: z.date() }))
      .query(async ({ ctx, input }) => {
        const profile = await db.getUserProfile(ctx.user.id);
        const summary = await db.getDailyNutritionSummary(ctx.user.id, input.date);
        return {
          ...summary,
          targets: profile ? {
            calories: profile.dailyCalorieTarget,
            protein: Number(profile.dailyProteinG),
            carbs: Number(profile.dailyCarbsG),
            fat: Number(profile.dailyFatG),
            fiber: Number(profile.dailyFiberG),
          } : null,
        };
      }),

    createMeal: protectedProcedure
      .input(z.object({
        mealType: z.enum(["breakfast", "lunch", "dinner", "snack"]),
        date: z.date(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.createMeal(ctx.user.id, input.mealType, input.date, input.notes);
        return { success: true };
      }),

    addIngredient: protectedProcedure
      .input(z.object({
        mealId: z.number(),
        name: z.string(),
        quantity: z.number().positive(),
        unit: z.string(),
        totalCalories: z.number().nonnegative(),
        proteinG: z.number().optional(),
        carbsG: z.number().optional(),
        fatG: z.number().optional(),
        fiberG: z.number().optional(),
        addedSugarsG: z.number().optional(),
        naturalSugarsG: z.number().optional(),
        sodiumMg: z.number().optional(),
        detectionConfidence: z.number().min(0).max(1).optional(),
        detectionMethod: z.enum(["manual", "aiDetected", "recipe"]),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.addIngredient(input.mealId, ctx.user.id, input as any);
        return { success: true };
      }),

    saveFavouriteMeal: protectedProcedure
      .input(z.object({
        name: z.string(),
        description: z.string().optional(),
        mealType: z.enum(["breakfast", "lunch", "dinner", "snack"]).optional(),
        ingredients: z.array(z.object({
          name: z.string(),
          quantity: z.number(),
          unit: z.string(),
          calories: z.number(),
          protein: z.number(),
          carbs: z.number(),
          fat: z.number(),
        })),
        totalCalories: z.number(),
        totalProteinG: z.number().optional(),
        totalCarbsG: z.number().optional(),
        totalFatG: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.saveFavouriteMeal(ctx.user.id, input as any);
        return { success: true };
      }),

    getFavouriteMeals: protectedProcedure.query(async ({ ctx }) => {
      return db.getFavouriteMeals(ctx.user.id);
    }),

    deleteFavouriteMeal: protectedProcedure
      .input(z.object({ favouriteMealId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteFavouriteMeal(ctx.user.id, input.favouriteMealId);
        return { success: true };
      }),

    logMealFromFavourite: protectedProcedure
      .input(z.object({ favouriteMealId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.logMealFromFavourite(ctx.user.id, input.favouriteMealId);
        return { success: true };
      }),
  }),

  /**
   * AI-powered fridge photo scanning and ingredient detection.
   */
  fridgeScanner: router({
    detectIngredients: protectedProcedure
      .input(z.object({
        imageUrl: z.string().url(),
        imageBase64: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Call LLM with vision to detect ingredients
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are a food detection expert. Analyze the image and identify all food items visible in the fridge.
              
Return a JSON array with detected items in this format:
[
  { "name": "item name", "confidence": 0.95, "quantity": "approximate amount", "unit": "g/ml/piece" },
  ...
]

Be specific about quantities and units. Use grams (g) for solid foods, milliliters (ml) for liquids.
Confidence should be 0-1 where 1 is certain and 0 is very uncertain.
Only include items you can clearly identify.`,
            },
            {
              role: "user",
              content: [
                {
                  type: "image_url",
                  image_url: {
                    url: input.imageUrl,
                    detail: "high",
                  },
                },
              ] as any,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "fridge_detection",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  items: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        name: { type: "string" },
                        confidence: { type: "number", minimum: 0, maximum: 1 },
                        quantity: { type: "number" },
                        unit: { type: "string" },
                      },
                      required: ["name", "confidence", "quantity", "unit"],
                    },
                  },
                },
                required: ["items"],
                additionalProperties: false,
              },
            },
          },
        });

        const content = response.choices[0]?.message.content;
        const parsed = JSON.parse(typeof content === "string" ? content : "{}");

        return {
          detectedItems: parsed.items || [],
          rawResponse: content,
        };
      }),

    saveFridgePhoto: protectedProcedure
      .input(z.object({
        photoBase64: z.string(),
        detectedIngredients: z.array(z.object({
          name: z.string(),
          confidence: z.number(),
          quantity: z.number().optional(),
          unit: z.string().optional(),
        })),
      }))
      .mutation(async ({ ctx, input }) => {
        // Convert base64 to buffer and upload to S3
        const buffer = Buffer.from(input.photoBase64, "base64");
        const { url, key } = await storagePut(
          `fridge-photos/${ctx.user.id}/${Date.now()}.jpg`,
          buffer,
          "image/jpeg"
        );

        await db.saveFridgePhoto(ctx.user.id, url, key, input.detectedIngredients);

        return { success: true, photoUrl: url, photoKey: key };
      }),

    getUserPhotos: protectedProcedure
      .input(z.object({ limit: z.number().default(10) }))
      .query(async ({ ctx, input }) => {
        return db.getUserFridgePhotos(ctx.user.id, input.limit);
      }),
  }),

  /**
   * Recipe generation from fridge ingredients.
   */
  recipes: router({
    generate: protectedProcedure
      .input(z.object({
        ingredients: z.array(z.object({
          name: z.string(),
          quantity: z.number().optional(),
          unit: z.string().optional(),
        })),
        dietaryRestrictions: z.array(z.string()).optional(),
        servings: z.number().default(1),
      }))
      .mutation(async ({ ctx, input }) => {
        const profile = await db.getUserProfile(ctx.user.id);

        const ingredientList = input.ingredients
          .map(i => `${i.quantity || "some"} ${i.unit || "portion"} of ${i.name}`)
          .join(", ");

        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are a professional nutritionist and chef. Create a healthy, personalized recipe using the provided ingredients.
              
Consider the user's dietary profile:
- Goal: ${profile?.dietaryGoal || "maintenance"}
- Restrictions: ${input.dietaryRestrictions?.join(", ") || "none"}
- Servings: ${input.servings}

Return a complete recipe with accurate nutritional information per serving.
Distinguish between added sugars and natural sugars in the breakdown.`,
            },
            {
              role: "user",
              content: `Create a recipe using these ingredients: ${ingredientList}. 
              
Please provide:
1. Recipe title and description
2. Prep and cook times
3. Step-by-step instructions
4. Nutritional breakdown per serving (calories, protein, carbs, fat, fiber, added sugars, natural sugars, sodium)
5. Dietary tags (vegan, gluten-free, etc.)`,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "recipe_generation",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  instructions: { type: "string" },
                  prepTimeMinutes: { type: "number" },
                  cookTimeMinutes: { type: "number" },
                  caloriesPerServing: { type: "number" },
                  proteinPerServingG: { type: "number" },
                  carbsPerServingG: { type: "number" },
                  fatPerServingG: { type: "number" },
                  fiberPerServingG: { type: "number" },
                  addedSugarsPerServingG: { type: "number" },
                  naturalSugarsPerServingG: { type: "number" },
                  sodiumPerServingMg: { type: "number" },
                  dietaryTags: { type: "array", items: { type: "string" } },
                },
                required: [
                  "title",
                  "description",
                  "instructions",
                  "prepTimeMinutes",
                  "cookTimeMinutes",
                  "caloriesPerServing",
                  "proteinPerServingG",
                  "carbsPerServingG",
                  "fatPerServingG",
                ],
                additionalProperties: false,
              },
            },
          },
        });

        const content = response.choices[0]?.message.content;
        const recipe = JSON.parse(typeof content === "string" ? content : "{}");

        await db.saveRecipe(ctx.user.id, {
          title: recipe.title,
          description: recipe.description,
          instructions: recipe.instructions,
          servings: input.servings,
          prepTimeMinutes: recipe.prepTimeMinutes,
          cookTimeMinutes: recipe.cookTimeMinutes,
          ingredients: input.ingredients as any,
          caloriesPerServing: recipe.caloriesPerServing as any,
          proteinPerServingG: recipe.proteinPerServingG as any,
          carbsPerServingG: recipe.carbsPerServingG as any,
          fatPerServingG: recipe.fatPerServingG as any,
          fiberPerServingG: recipe.fiberPerServingG as any,
          addedSugarsPerServingG: recipe.addedSugarsPerServingG as any,
          naturalSugarsPerServingG: recipe.naturalSugarsPerServingG as any,
          dietaryTags: recipe.dietaryTags as any,
          fridgePhotoId: undefined,
        } as any);

        return recipe;
      }),

    getUserRecipes: protectedProcedure
      .input(z.object({ limit: z.number().default(20) }))
      .query(async ({ ctx, input }) => {
        return db.getUserRecipes(ctx.user.id, input.limit);
      }),
  }),

  /**
   * Privacy and data handling.
   */
  privacy: router({
    getSettings: protectedProcedure.query(async ({ ctx }) => {
      return db.getPrivacySettings(ctx.user.id);
    }),

    updateSettings: protectedProcedure
      .input(z.object({
        allowAnalytics: z.boolean().optional(),
        allowDataExport: z.boolean().optional(),
        dataRetentionDays: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.updatePrivacySettings(ctx.user.id, {
          ...input,
          lastPrivacyReviewDate: new Date(),
        });
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
