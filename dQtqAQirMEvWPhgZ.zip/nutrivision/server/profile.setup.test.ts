import { describe, expect, it, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("profile.setup", () => {
  it("calculates daily calorie target using Harris-Benedict equation", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.profile.setup({
      age: 30,
      gender: "male",
      heightCm: 180,
      weightKg: 80,
      activityLevel: "moderate",
      dietaryGoal: "maintenance",
    });

    // Harris-Benedict for male: 88.362 + (13.397 * 80) + (4.799 * 180) - (5.677 * 30)
    // = 88.362 + 1071.76 + 863.82 - 170.31 = 1853.632
    // With moderate activity (1.55): 1853.632 * 1.55 = 2873.13
    expect(result.dailyCalorieTarget).toBeGreaterThan(2800);
    expect(result.dailyCalorieTarget).toBeLessThan(2950);
  });

  it("applies weight loss deficit (15%)", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const maintenanceResult = await caller.profile.setup({
      age: 30,
      gender: "male",
      heightCm: 180,
      weightKg: 80,
      activityLevel: "moderate",
      dietaryGoal: "maintenance",
    });

    const weightLossResult = await caller.profile.setup({
      age: 30,
      gender: "male",
      heightCm: 180,
      weightKg: 80,
      activityLevel: "moderate",
      dietaryGoal: "weightLoss",
    });

    // Weight loss should be ~85% of maintenance
    const ratio = weightLossResult.dailyCalorieTarget / maintenanceResult.dailyCalorieTarget;
    expect(ratio).toBeCloseTo(0.85, 0.02);
  });

  it("applies weight gain surplus (10%)", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const maintenanceResult = await caller.profile.setup({
      age: 30,
      gender: "male",
      heightCm: 180,
      weightKg: 80,
      activityLevel: "moderate",
      dietaryGoal: "maintenance",
    });

    const weightGainResult = await caller.profile.setup({
      age: 30,
      gender: "male",
      heightCm: 180,
      weightKg: 80,
      activityLevel: "moderate",
      dietaryGoal: "weightGain",
    });

    // Weight gain should be ~110% of maintenance
    const ratio = weightGainResult.dailyCalorieTarget / maintenanceResult.dailyCalorieTarget;
    expect(ratio).toBeCloseTo(1.1, 0.02);
  });

  it("calculates macro targets correctly", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.profile.setup({
      age: 30,
      gender: "male",
      heightCm: 180,
      weightKg: 80,
      activityLevel: "moderate",
      dietaryGoal: "maintenance",
    });

    // Default macros: 30% protein, 45% carbs, 25% fat
    // Protein: 30% * 2873 / 4 = ~215g
    // Carbs: 45% * 2873 / 4 = ~323g
    // Fat: 25% * 2873 / 9 = ~80g
    expect(result.dailyProteinG).toBeGreaterThan(200);
    expect(result.dailyProteinG).toBeLessThan(230);
    expect(result.dailyCarbsG).toBeGreaterThan(300);
    expect(result.dailyCarbsG).toBeLessThan(350);
    expect(result.dailyFatG).toBeGreaterThan(70);
    expect(result.dailyFatG).toBeLessThan(90);
  });

  it("increases protein for muscle gain goal", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const maintenanceResult = await caller.profile.setup({
      age: 30,
      gender: "male",
      heightCm: 180,
      weightKg: 80,
      activityLevel: "moderate",
      dietaryGoal: "maintenance",
    });

    const muscleGainResult = await caller.profile.setup({
      age: 30,
      gender: "male",
      heightCm: 180,
      weightKg: 80,
      activityLevel: "moderate",
      dietaryGoal: "muscleGain",
    });

    // Muscle gain should have higher protein ratio
    expect(muscleGainResult.dailyProteinG).toBeGreaterThan(maintenanceResult.dailyProteinG);
  });

  it("calculates different targets for female", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const maleResult = await caller.profile.setup({
      age: 30,
      gender: "male",
      heightCm: 165,
      weightKg: 70,
      activityLevel: "moderate",
      dietaryGoal: "maintenance",
    });

    const femaleResult = await caller.profile.setup({
      age: 30,
      gender: "female",
      heightCm: 165,
      weightKg: 70,
      activityLevel: "moderate",
      dietaryGoal: "maintenance",
    });

    // Female should have lower calorie target due to different BMR equation
    expect(femaleResult.dailyCalorieTarget).toBeLessThan(maleResult.dailyCalorieTarget);
  });

  it("respects activity level multipliers", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const sedentaryResult = await caller.profile.setup({
      age: 30,
      gender: "male",
      heightCm: 180,
      weightKg: 80,
      activityLevel: "sedentary",
      dietaryGoal: "maintenance",
    });

    const veryActiveResult = await caller.profile.setup({
      age: 30,
      gender: "male",
      heightCm: 180,
      weightKg: 80,
      activityLevel: "veryActive",
      dietaryGoal: "maintenance",
    });

    // Very active should have significantly higher target
    expect(veryActiveResult.dailyCalorieTarget).toBeGreaterThan(sedentaryResult.dailyCalorieTarget);
    const ratio = veryActiveResult.dailyCalorieTarget / sedentaryResult.dailyCalorieTarget;
    expect(ratio).toBeCloseTo(1.9 / 1.2, 0.05); // veryActive / sedentary multiplier ratio
  });

  it("returns success status", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.profile.setup({
      age: 30,
      gender: "male",
      heightCm: 180,
      weightKg: 80,
      activityLevel: "moderate",
      dietaryGoal: "maintenance",
    });

    expect(result.dailyCalorieTarget).toBeGreaterThan(0);
    expect(result.dailyProteinG).toBeGreaterThan(0);
    expect(result.dailyCarbsG).toBeGreaterThan(0);
    expect(result.dailyFatG).toBeGreaterThan(0);
  });
});
