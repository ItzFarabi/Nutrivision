import { eq } from "drizzle-orm";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { TRIAL_DAYS } from "./stripe-products";

/**
 * Set up a new user with trial access
 */
export async function setupUserTrial(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const trialEndDate = new Date();
  trialEndDate.setDate(trialEndDate.getDate() + TRIAL_DAYS);

  await db
    .update(users)
    .set({
      subscriptionStatus: "trial",
      trialEndDate,
    })
    .where(eq(users.id, userId));
}

/**
 * Check if user's trial has expired
 */
export async function isTrialExpired(userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user.length) return true;

  const userData = user[0];
  if (userData.subscriptionStatus !== "trial") return true;
  if (!userData.trialEndDate) return true;

  return new Date() > userData.trialEndDate;
}

/**
 * Activate pro subscription for a user
 */
export async function activateProSubscription(
  userId: number,
  stripeCustomerId: string,
  stripeSubscriptionId: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(users)
    .set({
      subscriptionStatus: "pro",
      stripeCustomerId,
      stripeSubscriptionId,
    })
    .where(eq(users.id, userId));
}

/**
 * Cancel subscription for a user
 */
export async function cancelSubscription(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(users)
    .set({
      subscriptionStatus: "cancelled",
    })
    .where(eq(users.id, userId));
}

/**
 * Get user subscription status
 */
export async function getUserSubscriptionStatus(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user.length) return null;

  const userData = user[0];
  return {
    status: userData.subscriptionStatus,
    trialEndDate: userData.trialEndDate,
    stripeCustomerId: userData.stripeCustomerId,
    stripeSubscriptionId: userData.stripeSubscriptionId,
  };
}

/**
 * Check if user is owner (gets free Pro access)
 */
export function isOwner(userId: number, ownerId?: number): boolean {
  if (!ownerId) return false;
  return userId === ownerId;
}

/**
 * Get effective subscription status (considering owner free access)
 */
export async function getEffectiveSubscriptionStatus(
  userId: number,
  ownerId?: number
): Promise<string> {
  // Owner always gets pro access
  if (isOwner(userId, ownerId)) {
    return "pro";
  }

  const subStatus = await getUserSubscriptionStatus(userId);
  if (!subStatus) return "free";

  // Check if trial expired
  if (subStatus.status === "trial") {
    if (subStatus.trialEndDate && new Date() > subStatus.trialEndDate) {
      return "free";
    }
    return "trial";
  }

  return subStatus.status;
}
