/**
 * Stripe product and price configuration for NutriVision subscriptions.
 * All prices are in GBP (£).
 */

export const STRIPE_PRODUCTS = {
  PRO_SUBSCRIPTION: {
    name: "NutriVision Pro",
    description: "Advanced recipe generator, personalized nutrition tracking, and premium features",
    priceGBP: 8, // £8 per month
    interval: "month" as const,
    currency: "gbp",
  },
};

/**
 * Trial configuration
 */
export const TRIAL_DAYS = 7; // 1 week free trial

/**
 * Feature access based on subscription tier
 */
export const FEATURES = {
  FREE: {
    dailyTracking: true,
    fridgeScanner: true,
    basicRecipes: true,
    advancedRecipes: false,
    mealHistory: true,
    privacyControls: true,
  },
  TRIAL: {
    dailyTracking: true,
    fridgeScanner: true,
    basicRecipes: true,
    advancedRecipes: true, // Full access during trial
    mealHistory: true,
    privacyControls: true,
  },
  PRO: {
    dailyTracking: true,
    fridgeScanner: true,
    basicRecipes: true,
    advancedRecipes: true,
    mealHistory: true,
    privacyControls: true,
  },
};

/**
 * Get feature access for a user based on subscription status
 */
export function getFeatureAccess(subscriptionStatus: string) {
  switch (subscriptionStatus) {
    case "pro":
      return FEATURES.PRO;
    case "trial":
      return FEATURES.TRIAL;
    case "free":
    default:
      return FEATURES.FREE;
  }
}

/**
 * Check if user has access to advanced recipes
 */
export function hasAdvancedRecipes(subscriptionStatus: string): boolean {
  const features = getFeatureAccess(subscriptionStatus);
  return features.advancedRecipes;
}
