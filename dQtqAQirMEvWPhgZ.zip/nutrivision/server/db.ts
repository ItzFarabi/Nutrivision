import { eq, and, desc, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users,
  userProfiles,
  meals,
  ingredients,
  fridgePhotos,
  recipes,
  mealPhotos,
  privacySettings,
  favouriteMeals,
  type UserProfile,
  type Meal,
  type Ingredient,
  type FridgePhoto,
  type Recipe,
  type PrivacySettings,
  type FavouriteMeal,
  type InsertFavouriteMeal,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get or create user profile with personalized calorie/macro targets.
 */
export async function getUserProfile(userId: number): Promise<UserProfile | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertUserProfile(userId: number, profile: Partial<UserProfile>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getUserProfile(userId);
  
  if (existing) {
    await db.update(userProfiles).set(profile).where(eq(userProfiles.userId, userId));
  } else {
    await db.insert(userProfiles).values({
      userId,
      ...profile,
    });
  }
}

/**
 * Get meals for a user on a specific date.
 */
export async function getMealsByDate(userId: number, date: Date) {
  const db = await getDb();
  if (!db) return [];

  const dateStr = date.toISOString().split('T')[0];
  return db.select().from(meals).where(
    and(
      eq(meals.userId, userId),
      eq(meals.date, dateStr as any)
    )
  );
}

/**
 * Create a new meal entry.
 */
export async function createMeal(userId: number, mealType: string, date: Date, notes?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const dateStr = date.toISOString().split('T')[0];
  const result = await db.insert(meals).values({
    userId,
    mealType: mealType as any,
    date: dateStr as any,
    notes,
  });

  return result;
}

/**
 * Get all ingredients for a meal.
 */
export async function getMealIngredients(mealId: number) {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(ingredients).where(eq(ingredients.mealId, mealId));
}

/**
 * Add ingredient to a meal.
 */
export async function addIngredient(
  mealId: number,
  userId: number,
  ingredient: Omit<Ingredient, 'id' | 'createdAt' | 'updatedAt' | 'mealId' | 'userId'>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(ingredients).values([
    {
      mealId,
      userId,
      ...ingredient,
    } as any,
  ]);
}

/**
 * Get daily nutrition summary for a user on a specific date.
 */
export async function getDailyNutritionSummary(userId: number, date: Date) {
  const db = await getDb();
  if (!db) return null;

  const userMeals = await getMealsByDate(userId, date);
  const mealIds = userMeals.map(m => m.id);

  if (mealIds.length === 0) {
    return {
      totalCalories: 0,
      totalProteinG: 0,
      totalCarbsG: 0,
      totalFatG: 0,
      totalFiberG: 0,
      totalAddedSugarsG: 0,
      totalNaturalSugarsG: 0,
      totalSodiumMg: 0,
      mealCount: 0,
    };
  }

  const result = await db.select().from(ingredients).where(
    and(
      ...mealIds.map(id => eq(ingredients.mealId, id))
    )
  );

  const summary = {
    totalCalories: 0,
    totalProteinG: 0,
    totalCarbsG: 0,
    totalFatG: 0,
    totalFiberG: 0,
    totalAddedSugarsG: 0,
    totalNaturalSugarsG: 0,
    totalSodiumMg: 0,
    mealCount: userMeals.length,
  };

  result.forEach(ing => {
    summary.totalCalories += Number(ing.totalCalories) || 0;
    summary.totalProteinG += Number(ing.proteinG) || 0;
    summary.totalCarbsG += Number(ing.carbsG) || 0;
    summary.totalFatG += Number(ing.fatG) || 0;
    summary.totalFiberG += Number(ing.fiberG) || 0;
    summary.totalAddedSugarsG += Number(ing.addedSugarsG) || 0;
    summary.totalNaturalSugarsG += Number(ing.naturalSugarsG) || 0;
    summary.totalSodiumMg += Number(ing.sodiumMg) || 0;
  });

  return summary;
}

/**
 * Store fridge photo and detected ingredients.
 */
export async function saveFridgePhoto(
  userId: number,
  photoUrl: string,
  photoKey: string,
  detectedIngredients: Array<{ name: string; confidence: number; quantity?: number; unit?: string }>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(fridgePhotos).values([
    {
      userId,
      photoUrl,
      photoKey,
      detectedIngredients: detectedIngredients as any,
    },
  ]);
}

/**
 * Get fridge photos for a user.
 */
export async function getUserFridgePhotos(userId: number, limit = 10) {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(fridgePhotos)
    .where(eq(fridgePhotos.userId, userId))
    .orderBy(desc(fridgePhotos.createdAt))
    .limit(limit);
}

/**
 * Save generated recipe.
 */
export async function saveRecipe(
  userId: number,
  recipe: Omit<Recipe, 'id' | 'createdAt' | 'userId'>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(recipes).values([
    {
      userId,
      ...recipe,
    } as any,
  ]);
}

/**
 * Get recipes for a user.
 */
export async function getUserRecipes(userId: number, limit = 20) {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(recipes)
    .where(eq(recipes.userId, userId))
    .orderBy(desc(recipes.createdAt))
    .limit(limit);
}

/**
 * Get or create privacy settings for a user.
 */
export async function getPrivacySettings(userId: number): Promise<PrivacySettings | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(privacySettings).where(eq(privacySettings.userId, userId)).limit(1);
  
  if (result.length === 0) {
    // Create default privacy settings
    await db.insert(privacySettings).values([
      {
        userId,
        allowAnalytics: false,
        allowDataExport: true,
        dataRetentionDays: 365,
      },
    ]);
    return getPrivacySettings(userId);
  }

  return result[0];
}

/**
 * Update privacy settings for a user.
 */
export async function updatePrivacySettings(userId: number, settings: Partial<PrivacySettings>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(privacySettings).set(settings).where(eq(privacySettings.userId, userId));
}


/**
 * Save a favourite meal for quick logging.
 */
export async function saveFavouriteMeal(userId: number, data: InsertFavouriteMeal) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(favouriteMeals).values({
    ...data,
    userId,
  });
}

/**
 * Get all favourite meals for a user.
 */
export async function getFavouriteMeals(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.select().from(favouriteMeals).where(eq(favouriteMeals.userId, userId));
}

/**
 * Delete a favourite meal.
 */
export async function deleteFavouriteMeal(userId: number, favouriteMealId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(favouriteMeals)
    .where(and(eq(favouriteMeals.userId, userId), eq(favouriteMeals.id, favouriteMealId)));
}

/**
 * Log a meal from a favourite.
 */
export async function logMealFromFavourite(userId: number, favouriteMealId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const favourite = await db.select().from(favouriteMeals)
    .where(and(eq(favouriteMeals.userId, userId), eq(favouriteMeals.id, favouriteMealId)))
    .limit(1);

  if (!favourite[0]) throw new Error("Favourite meal not found");

  // Create meal and get the last inserted ID
  await createMeal(userId, favourite[0].mealType || "snack", new Date());
  
  // Get the meal we just created
  const meals_list = await db.select().from(meals)
    .where(eq(meals.userId, userId))
    .orderBy(desc(meals.createdAt))
    .limit(1);
  
  const mealId = meals_list[0]?.id;
  if (!mealId) throw new Error("Failed to create meal");
  
  if (favourite[0].ingredients && Array.isArray(favourite[0].ingredients)) {
    for (const ing of favourite[0].ingredients) {
      await addIngredient(mealId, userId, {
        name: ing.name,
        quantity: ing.quantity,
        unit: ing.unit,
        totalCalories: ing.calories,
        proteinG: ing.protein,
        carbsG: ing.carbs,
        fatG: ing.fat,
        detectionMethod: "manual",
      } as any);
    }
  }

  // Increment times logged
  await db.update(favouriteMeals)
    .set({ timesLogged: (favourite[0].timesLogged || 0) + 1 })
    .where(eq(favouriteMeals.id, favouriteMealId));

  return { success: true };
}
