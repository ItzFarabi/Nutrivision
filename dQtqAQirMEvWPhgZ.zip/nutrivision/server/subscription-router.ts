import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import Stripe from "stripe";
import * as subscription from "./subscription";
import { STRIPE_PRODUCTS } from "./stripe-products";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

export const subscriptionRouter = router({
  /**
   * Get current subscription status
   */
  getStatus: protectedProcedure.query(async ({ ctx }) => {
    const status = await subscription.getUserSubscriptionStatus(ctx.user.id);
    return {
      status: status?.status || "free",
      trialEndDate: status?.trialEndDate,
      isOwner: ctx.user.id === parseInt(process.env.OWNER_OPEN_ID || "0"),
    };
  }),

  /**
   * Create checkout session for subscription
   */
  createCheckoutSession: protectedProcedure.query(async ({ ctx }) => {
    try {
      // Get or create Stripe customer
      let customerId = (await subscription.getUserSubscriptionStatus(ctx.user.id))
        ?.stripeCustomerId;

      if (!customerId) {
        const customer = await stripe.customers.create({
          email: ctx.user.email || undefined,
          name: ctx.user.name || undefined,
          metadata: {
            userId: ctx.user.id.toString(),
          },
        });
        customerId = customer.id;
      }

      // Create checkout session
      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        mode: "subscription",
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: STRIPE_PRODUCTS.PRO_SUBSCRIPTION.currency,
              product_data: {
                name: STRIPE_PRODUCTS.PRO_SUBSCRIPTION.name,
                description: STRIPE_PRODUCTS.PRO_SUBSCRIPTION.description,
              },
              unit_amount: STRIPE_PRODUCTS.PRO_SUBSCRIPTION.priceGBP * 100, // Convert to pence
              recurring: {
                interval: STRIPE_PRODUCTS.PRO_SUBSCRIPTION.interval,
              },
            },
            quantity: 1,
          },
        ],
        success_url: `${ctx.req.headers.origin}/dashboard?subscription=success`,
        cancel_url: `${ctx.req.headers.origin}/subscription?cancelled=true`,
        client_reference_id: ctx.user.id.toString(),
        metadata: {
          userId: ctx.user.id.toString(),
          userEmail: ctx.user.email || "",
        },
      });

      return {
        checkoutUrl: session.url,
      };
    } catch (error) {
      console.error("Stripe checkout error:", error);
      throw new Error("Failed to create checkout session");
    }
  }),

  /**
   * Get subscription details
   */
  getDetails: protectedProcedure.query(async ({ ctx }) => {
    const status = await subscription.getEffectiveSubscriptionStatus(
      ctx.user.id,
      parseInt(process.env.OWNER_OPEN_ID || "0")
    );

    const subStatus = await subscription.getUserSubscriptionStatus(ctx.user.id);

    return {
      status,
      trialEndDate: subStatus?.trialEndDate,
      isOwner: ctx.user.id === parseInt(process.env.OWNER_OPEN_ID || "0"),
      monthlyPrice: STRIPE_PRODUCTS.PRO_SUBSCRIPTION.priceGBP,
      currency: "GBP",
    };
  }),

  /**
   * Cancel subscription
   */
  cancelSubscription: protectedProcedure.mutation(async ({ ctx }) => {
    const subStatus = await subscription.getUserSubscriptionStatus(ctx.user.id);

    if (!subStatus?.stripeSubscriptionId) {
      throw new Error("No active subscription to cancel");
    }

    try {
      await stripe.subscriptions.cancel(subStatus.stripeSubscriptionId);
      await subscription.cancelSubscription(ctx.user.id);

      return { success: true };
    } catch (error) {
      console.error("Stripe cancellation error:", error);
      throw new Error("Failed to cancel subscription");
    }
  }),
});
